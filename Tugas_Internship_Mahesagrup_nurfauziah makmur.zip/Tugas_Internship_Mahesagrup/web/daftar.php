<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Halaman Daftar</title>
  </head>
  <body>
      <div class="container p-5">
          <div class="row justify-content-center">
              <div class="col-md-5">
              <div class="card">
                  <!-- -============================FORM========================================== -->
                  <form action="" method="post">
                    <div class="card-header text-center">
                        Halaman Daftar
                    </div>
                    <div class="card-body">
                        
                    <label for="username" class="form-label">Username</label>
                    <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon3"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-plus-fill" viewBox="0 0 16 16">
                    <path d="M1 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
                    <path fill-rule="evenodd" d="M13.5 5a.5.5 0 0 1 .5.5V7h1.5a.5.5 0 0 1 0 1H14v1.5a.5.5 0 0 1-1 0V8h-1.5a.5.5 0 0 1 0-1H13V5.5a.5.5 0 0 1 .5-.5z"/>
                    </svg></span>
                    <input type="text" class="form-control" id="username" aria-describedby="basic-addon3" name="username">
                    </div>

                    <label for="password" class="form-label">Password</label>
                    <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon3"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key-fill" viewBox="0 0 16 16">
                    <path d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/>
                    </svg></span>
                    <input type="password" class="form-control" id="password" aria-describedby="basic-addon3" name="password">
                    </div>
                   <div class="row text-center">
                   <button type="submit" class="btn btn-primary" name="daftar">Daftar</button>
                   <p>Sudah Punya Akun? Silahkan <a href="login.php">Login</a></p>
                   </div> 


                    </div>
                    </div>
                    </form>
              </div>
          </div>
      </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

  </body>
</html>
<?php
include 'koneksi.php';
if(isset($_POST['daftar'])){
    $username=$_POST['username'];
    $password=password_hash($_POST['password'],PASSWORD_BCRYPT);
    $sql="INSERT INTO masuk VALUES ('$username','$password')";
    $query_run=mysqli_query($conn,$sql);
    if($query_run){
        header('location:login.php');
    }
}

?>

