
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

    <title>Edit</title>
  </head>
  <body>
 <div class="container">
 <nav class="navbar navbar-light bg-light">
  <div class="container-fluid">
    <a class="navbar-brand">Maesa Group</a>
    
</nav>
<figure class="text-center">
  <blockquote class="blockquote">
    <p>A well-known quote, contained in a blockquote element.</p>
  </blockquote>
  <figcaption class="blockquote-footer">
    Someone famous in <cite title="Source Title">Source Title</cite>
  </figcaption>
</figure>
<?php
include 'koneksi.php';
$edit_id=$_GET['id'];
$query="SELECT * FROM pegawai WHERE id='$edit_id'";
$query_run=mysqli_query($conn,$query);

while($data=mysqli_fetch_array($query_run)){
?>

<form action="" method="post" enctype="multipart/form-data">
<div class="mb-3 row">
    <label for="kode" class="col-sm-2 col-form-label">Kode Pegawai</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="kode" name="kode" value="<?php echo $data ['kode'] ?>">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="nama" class="col-sm-2 col-form-label">Nama</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $data ['nama'] ?>">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="jabatan" class="col-sm-2 col-form-label">Jabatan</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?php echo $data ['jabatan'] ?>">
    </div>
  </div>

  <div class="mb-3 row">
    <label for="gaji" class="col-sm-2 col-form-label">Gaji</label>
    <div class="col-sm-10">
      <input type="number" class="form-control" id="gaji" name="gaji" value="<?php echo $data ['gaji'] ?>">
    </div>
  </div>
  <div class="mb-3 row">
  <button type="submit" class="btn btn-primary" name="edit">Tambahkan Data</button>
</div>
</form>
<?php
}
?>

 </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>


  </body>
</html>

<?php
include 'koneksi.php';
if(isset($_POST['edit'])){
    $edit_id=$_GET['id'];
    $kode=$_POST['kode'];
    $nama=$_POST['nama'];
    $jabatan=$_POST['jabatan'];
    $gaji=$_POST['gaji'];

    $query="UPDATE pegawai SET kode='$kode',nama='$nama',jabatan='$jabatan',gaji='$gaji' WHERE id='$edit_id'";
    $query_run=mysqli_query($conn,$query);

    if($query_run){
      
        echo '
        <script>
        alert("Berhasil Mengubah Data!");window.location.href="index.php";
        </script>
        ';
    }
}
?>