-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Mar 2022 pada 15.46
-- Versi server: 10.4.20-MariaDB
-- Versi PHP: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tgs_maesa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `masuk`
--

CREATE TABLE `masuk` (
  `username` varchar(50) NOT NULL,
  `kata_sandi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `masuk`
--

INSERT INTO `masuk` (`username`, `kata_sandi`) VALUES
('', '$2y$10$hEfVo76W6.vPapQge0EZy.haKa/jurfaFZeNzVQdz9YMHgOr0.Q6i'),
('admin', '$2y$10$zBeY8x1Quqd2CrymAPDqvuD0Tk9MKO1s.32Ep.lOsC4LCoMrEciGa'),
('cia', '$2y$10$6d4/4YzHL2TVjf3Mp8mvM.HuGa1orY7/BwcNatOThNkLOmGUcFN4G'),
('cia10', '$2y$10$3RMeavOFUl9LkyL3kljGVu2Buyz8Yjgdfmc/dJoLWX19JvPjTH1KS'),
('cia100', '$2y$10$V73af5yskqc4O4cjGC0xAu5wIkPWkpPkJYnI9a46WcDawVPMY1DMy'),
('cia11', '$2y$10$t4xP9UIY5wmhXw2bfF1k6eHYgDJ9BJ5X1wn9s2IBK8yRtvNkuXTBa'),
('cia111', '$2y$10$Vg1toZIGtEziFU76K1VaGe1gMHvr9lAt89fhZhl6rRJAQ57xMTXpi'),
('cia11111111', '$2y$10$8qWDq4OBQp6DZDlEecB1fOlZFnsgjdZjYFDXXr1Qg5nbLMMt/cocS'),
('cia2', '202cb962ac59075b964b07152d234b70'),
('cia200', '$2y$10$NwtiJa2icIdVQjwF1sMZvOgVB/t8byAOk5U/amhPJON38INzvf.nS'),
('cia210', '$2y$10$PxeJxE9VwJcNYz9iCCsrG.QuyXk6mccpD.wWFRBPQ9AeKAzrdVHJ6'),
('cia220', '$2y$10$0Vzwr6AwFpNi4lnzWX4xwuRelFT0/vARu57Mqfky/YsAnh5/WY4xi'),
('cia230', '$2y$10$mUj7r3RMmnfBUM0PnW4LSuGp9VfPsht2/BxnKqpJdfeZ6WkzCrVfa'),
('cia3', '$2y$10$3dqzfQO9l5ZXBgmbglpAee6Icc35MeIntZqp48opxLCPNNZpCy1PO'),
('cia4', '$2y$10$e6/59i7QNYA4ewcKLRY1LOaVsSZfLWKbwyJ2ix0siqN2LkLxmZdqe'),
('pausia', '$2y$10$LdOXwxLSWa4WlAV7.2kDNubA0ZyDh9Bh6xtb2JTVF1Vzk3JlT8RnW'),
('pausia0205', '$2y$10$0tvWZR3Q1O9PHMVBT7aFjOEQj.z4vfM5b0hL.6q396ggflkDfRVza');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id` int(11) NOT NULL,
  `kode` varchar(35) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `jabatan` varchar(35) NOT NULL,
  `gaji` int(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id`, `kode`, `nama`, `jabatan`, `gaji`) VALUES
(3, 'e4r4r4', 'suno', 'ui.ux', 2147483647);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama` varchar(35) NOT NULL,
  `harga` int(35) NOT NULL,
  `exp` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `masuk`
--
ALTER TABLE `masuk`
  ADD PRIMARY KEY (`username`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
