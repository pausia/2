<?php
include 'koneksi.php';
$hapus_id=$_GET['id'];
$query="DELETE FROM pegawai WHERE id='$hapus_id'";

$query_run=mysqli_query($conn,$query);

if($query_run){
    echo '
    <script>
    alert("Berhasil Menghapus Data!");window.location.href="index.php";
    </script>
    ';
}

?>