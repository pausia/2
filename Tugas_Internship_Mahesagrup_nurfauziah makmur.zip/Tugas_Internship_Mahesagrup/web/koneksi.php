<?php
$conn=mysqli_connect("localhost","root","","tgs_maesa");
?>