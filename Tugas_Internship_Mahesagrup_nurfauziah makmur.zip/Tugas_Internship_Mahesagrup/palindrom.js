// program untuk pencekkan apakah suatu kata itu palindrome atau tidak

function checkPalindrome(str) {

    //cari panjang tali
    const len = string.length;

    // loop melalui setengah dari string
    for (let i = 0; i < len / 2; i++) {

        // periksa apakah string pertama dan terakhir sama
        if (string[i] !== string[len - 1 - i]) {
            return '--> bukan Palindrome';
        }
    }
    return '--> merupakan Palindrome';
}

// take input
const string = prompt('Enter a string: ');

// panggil functionnya
const value = checkPalindrome(string);

document.getElementById("root").innerHTML= string+' '+value;